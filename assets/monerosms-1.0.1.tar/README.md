# MoneroSMS.com CLI

This is a command line interface for MoneroSMS.com.

Requires python3.10+ and the requests library.

See monerosms.com for more info. Contact me privately at admin@monerosms.com to report security bugs or for account support.